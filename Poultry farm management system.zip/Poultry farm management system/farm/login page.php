<?php
// Database configuration
$host = 'localhost';
$dbname = 'poultry';
$username = 'root';
$password = '';

try {
    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get form data
    $user = $_POST['username'];
    $pass = $_POST['password'];
    
    // Prepare SQL query
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $user);
    $stmt->execute();
    
    // Check if user exists
    if($stmt->rowCount() > 0) {
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verify password
        if(password_verify($pass, $userData['password'])) {
            // Start session and store user data
            session_start();
            $_SESSION['user_id'] = $userData['id'];
            $_SESSION['username'] = $userData['username'];
            $_SESSION['role'] = $userData['role'];
            
            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            // Invalid password
            header("Location: login.html?error=invalid");
            exit();
        }
    } else {
        // User not found
        header("Location: login.html?error=notfound");
        exit();
    }
} catch(PDOException $e) {
    // Database error
    die("Database error: " . $e->getMessage());
}
?>