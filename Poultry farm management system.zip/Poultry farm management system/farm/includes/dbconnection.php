<?php 
// DB credentials
$host = 'localhost';
$dbname = 'poultry';
$username = 'root';
$password = '';

try {
    // First, connect to MySQL without specifying database
    $conn = new PDO(
        "mysql:host=$host;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Check if database exists
    $stmt = $conn->query("SHOW DATABASES LIKE '$dbname'");
    if ($stmt->rowCount() == 0) {
        // Database doesn't exist, create it
        $conn->exec("CREATE DATABASE $dbname");
        error_log("Database created successfully");
    }
    
    // Now connect to the specific database
    $dbh = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Set timezone
    $dbh->exec("SET time_zone = '+05:30'");
    
    // Log connection success
    error_log("Database connection established successfully");
    
    // Check if tbladmin exists
    $stmt = $dbh->query("SHOW TABLES LIKE 'tbladmin'");
    if ($stmt->rowCount() == 0) {
        // Table doesn't exist, show setup message
        header('Content-Type: text/html; charset=UTF-8');
        echo "<div class='alert alert-warning'>
                <h4>Database Setup Required</h4>
                <p>Please import the database structure from SQL File/poultry.sql before using the application.</p>
                <p>1. Open phpMyAdmin (http://localhost/phpmyadmin)</p>
                <p>2. Select the 'poultry' database</p>
                <p>3. Click 'Import' and select SQL File/poultry.sql</p>
              </div>";
        exit;
    }
} catch (PDOException $e) {
    // Log error
    error_log("Database connection failed: " . $e->getMessage());
    
    // Show user-friendly error
    header('Content-Type: text/html; charset=UTF-8');
    echo "<div class='alert alert-danger'>
            <h4>Database Connection Error</h4>
            <p>Could not connect to the database. Please ensure:</p>
            <ul>
                <li>MySQL service is running in XAMPP</li>
                <li>The database exists and is properly imported</li>
                <li>Database credentials are correct</li>
            </ul>
            <p>For help, check the error log in your web server's logs directory.</p>
          </div>";
    exit;
}
?>