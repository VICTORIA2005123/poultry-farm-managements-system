// Handle login form submission
jQuery(document).ready(function($) {
    if (typeof $ === 'undefined') {
        console.error('jQuery not loaded');
        return;
    }

    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = $(this).serialize();
        
        // Show loading state
        const $button = $(this).find('button[type="submit"]');
        if ($button.length === 0) {
            console.error('Login button not found');
            return;
        }
        
        $button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Signing in...');
        
        // Submit form via AJAX
        $.ajax({
            url: window.location.href, // Submit to current page (index.php)
            type: 'POST',
            data: formData,
            success: function(response) {
                // If response is HTML, it means we're being redirected
                if (response.includes('<!DOCTYPE html>')) {
                    $button.prop('disabled', false).html('SIGN IN');
                    // The redirect is already happening, no need to do anything
                    return;
                }
                
                try {
                    // Try to parse as JSON
                    const result = JSON.parse(response);
                    if (result.success) {
                        $button.prop('disabled', false).html('SIGN IN');
                        window.location.href = result.redirect || 'dashboard.php';
                    } else {
                        $button.prop('disabled', false).html('SIGN IN');
                        alert(result.message || 'Invalid credentials');
                    }
                } catch (error) {
                    // If not JSON, treat as HTML response
                    console.error('Not a JSON response:', error);
                    $button.prop('disabled', false).html('SIGN IN');
                    // The server will handle the redirect
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                $button.prop('disabled', false).html('SIGN IN');
                alert('An error occurred during login. Please try again.');
            }
        });
    });
});
